<?php
namespace App\Http\Controllers\API;

use \App\Models\Cars as Car;
use App\Http\Controllers\Controller;
use api_beauty\Transformers\CarTransformer;
use App\Models\CustomerCar;
use Illuminate\Http\Response;
use LucaDegasperi\OAuth2Server\Authorizer;

/**
 * Created by PhpStorm.
 * User: Speridian
 * Date: 6/21/2016
 * Time: 3:47 PM
 */
class CarController extends  Controller
{


    protected $carTransformer;

    /*FoodTransformer $FoodTransformer*/
    public function __construct(
        CarTransformer $CarTransformer
    )
    {
        $this->carTransformer = $CarTransformer;
        /*	$this->middleware('auth');*/
    }



    public function index(Authorizer $authorizer) {

/*        return view('public.cars')
            ->with('cars', Car::all());*/


        $user_id=$authorizer->getResourceOwnerId(); // the token user_id

        $user=\App\User::find($user_id);// get the user data from database
        $cars= CustomerCar::where('customer_id','=',$user->id)->get();



        //return $cars;

       // $cars = Car::all();

        return Response()->json([
            'cars' => $this->carTransformer->transformCollection($cars->all())
        ]);



    }

}