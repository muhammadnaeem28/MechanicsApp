<?php
namespace App\Http\Controllers\WEB;

use \App\Models\Cars as Car;
use App\Http\Controllers\Controller;
use api_beauty\Transformers\CarTransformer;
use Illuminate\Http\Response;

/**
 * Created by PhpStorm.
 * User: Speridian
 * Date: 6/21/2016
 * Time: 3:47 PM
 */
class CarController extends  Controller
{

    public function index() {

        return view('admin.layouts.main');
            //->with('cars', Car::all());


    }

}