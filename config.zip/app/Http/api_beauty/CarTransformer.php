<?php

namespace api_beauty\Transformers;

class CarTransformer extends Transformer {


    public function transform($item){

        return [
            'id' => $item['id'],
            'brand' => $item['brand'],

        ];
    }
}