<?php

namespace api_beauty\Transformers;



abstract Class Transformer {

    public function transformCollection(array $items)
    {

        return array_map([$this, 'transform'], $items);
    }



    public abstract function transform($item);




}


