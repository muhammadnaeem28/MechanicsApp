<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group(['prefix'=>'api','before' => 'oauth'], function()
{
//    Route::get('/posts',  'PostController@index');
    Route::get('/cars', ['as' => 'api.cars.index', 'uses' => 'API\CarController@index']);
});

//Route::group(['prefix' => 'api', 'middleware' => 'isAdmin'], function() {

/*Route::group(['prefix' => 'api'], function() {

  Route::get('/cars', ['as' => 'api.cars.index', 'uses' => 'API\CarController@index']);
});*/

Route::group(['prefix' => 'admin'], function() {

    Route::get('/index', ['as' => 'admin.index', 'uses' => 'WEB\CarController@index']);
});

// Authentication routes...
Route::get('auth/login', 'Auth\AuthController@getLogin');
Route::post('auth/login', 'Auth\AuthController@postLogin');
Route::get('auth/logout', 'Auth\AuthController@getLogout');

// Registration routes...
Route::get('auth/register', 'Auth\AuthController@getRegister');
Route::post('auth/register', 'Auth\AuthController@postRegister');


Route::controllers([
    'password' => 'Auth\PasswordController',
]);


Route::post('oauth/access_token', function() {
    return Response::json(Authorizer::issueAccessToken());
});


Route::get('/register ',function(){$user = new \App\User();
    $user->fname="ftest";
    $user->lname="ltest";
    $user->email="test@test.com";
    $user->password = \Illuminate\Support\Facades\Hash::make("password");
    $user->save();

});

/*Route::get('api', ['before' => 'oauth', function() {
    // return the protected resource
    //echo �success authentication�;
    $user_id=Authorizer::getResourceOwnerId(); // the token user_id
    $user=\App\User::find($user_id);// get the user data from database
    return Response::json($user);
}]);*/