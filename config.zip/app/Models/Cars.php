<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\App;
use Illuminate\Database\Eloquent\Model as Eloquent;

class Cars extends Eloquent
{
    protected $table = "c_brands";


/*    public function experiences(){
        return $this->hasMany(Experience::class,'c_id');
    }*/

}

