<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('fname');
            $table->string('lname');
            $table->string('email')->unique();
            $table->string('password', 60);
            $table->string('image_url')->nullable();
            $table->string('street_address')->nullable();
            $table->string('city')->nullable();
            $table->string('state')->nullable();
            $table->integer('zip')->nullable();
            $table->string('lnt')->nullable();
            $table->string('lng')->nullable();
            $table->string('phone1')->nullable();
            $table->string('phone2')->nullable();
            $table->string('languages')->nullable();
            $table->text('biography')->nullable();
            $table->integer('experience')->nullable();
            $table->enum('role', ['customer','mechanic','admin'])->default('customer');
            $table->float('avg_rating')->nullable();
            $table->integer('rating_count')->nullable();

            $table->boolean('active')->default(0);
            $table->boolean('news_letters')->default(0);
            $table->boolean('sms_alerts')->default(0);
            $table->boolean('verified')->default(0);
            $table->dateTime('last_login')->nullable();
            $table->rememberToken();
            $table->timestamps();


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('users');
    }
}
