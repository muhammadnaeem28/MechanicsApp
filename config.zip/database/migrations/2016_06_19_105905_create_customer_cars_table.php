<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCustomerCarsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customer_cars', function (Blueprint $table) {
            $table->increments('id');

            $table->integer('customer_id')->unsigned();
            $table->foreign('customer_id')->references('id')->on('users')->onDelete('cascade');

            $table->integer('cm_id')->unsigned();
            $table->foreign('cm_id')->references('id')->on('c_brand_year_models')->onDelete('cascade');

            $table->string('brand')->nullable();
            $table->string('year')->nullable();
            $table->string('model')->nullable();
            $table->string('total_mileage')->nullable();
            $table->string('daily_mileage')->nullable();
            $table->string('desc')->nullable();

            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('customer_cars');
    }
}
