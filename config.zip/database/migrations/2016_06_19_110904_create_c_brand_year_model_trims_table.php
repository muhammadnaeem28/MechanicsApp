<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCBrandYearModelTrimsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('c_brand_year_model_trims', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('cm_id')->unsigned();
            $table->foreign('cm_id')->references('id')->on('c_brand_year_models')->onDelete('cascade');
            $table->string('name');
            $table->string('image_url')->nullable();
            $table->text('desc')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('c_brand_year_model_trims');
    }
}
