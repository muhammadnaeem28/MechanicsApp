<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSPricesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('s_prices', function (Blueprint $table) {

            $table->increments('id');

            $table->integer('cb_id')->unsigned();
            $table->foreign('cb_id')->references('id')->on('c_brands')->onDelete('cascade')->nullable();
            $table->string('car_brand')->nullable();

            $table->integer('cm_id')->unsigned();
            $table->foreign('cm_id')->references('id')->on('c_brand_years')->onDelete('cascade')->nullable();
            $table->string('car_model')->nullable();

            $table->integer('cy_id')->unsigned();
            $table->foreign('cy_id')->references('id')->on('c_brand_year_models')->onDelete('cascade')->nullable();
            $table->string('car_year')->nullable();

            $table->integer('ct_id')->unsigned();
            $table->foreign('ct_id')->references('id')->on('c_brand_year_model_trims')->onDelete('cascade')->nullable();
            $table->string('car_trim')->nullable();

            $table->integer('s_id')->unsigned();
            $table->foreign('s_id')->references('id')->on('s_category_services')->onDelete('cascade');
            $table->string('s_name')->nullable();
            $table->string('s_price')->nullable();

            $table->integer('os_id')->unsigned();
            $table->foreign('os_id')->references('id')->on('service_optionals')->onDelete('cascade')->nullable();
            $table->string('os_name')->nullable();
            $table->string('os_price')->nullable();

            $table->string('desc')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('s_prices');
    }
}
