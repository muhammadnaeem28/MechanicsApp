<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSCategoryServicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('s_category_services', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('s_category_id')->unsigned();
            $table->foreign('s_category_id')->references('id')->on('s_categories')->onDelete('cascade');
            $table->string('name');
            $table->string('price');
            $table->string('image_url')->nullable();
            $table->text('desc')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('s_category_services');
    }
}
