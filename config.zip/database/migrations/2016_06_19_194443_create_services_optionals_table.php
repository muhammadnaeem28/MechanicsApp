<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateServicesOptionalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('services_optionals', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('s_id')->unsigned();
            $table->foreign('s_id')->references('id')->on('s_category_services')->onDelete('cascade');
            $table->integer('os_id')->unsigned();
            $table->foreign('os_id')->references('id')->on('service_optionals')->onDelete('cascade');
            $table->string('price');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('services_optionals');
    }
}
