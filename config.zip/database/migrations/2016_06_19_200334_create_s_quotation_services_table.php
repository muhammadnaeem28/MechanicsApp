<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSQuotationServicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('s_quotation_services', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('s_quotation_id')->unsigned();
            $table->foreign('s_quotation_id')->references('id')->on('s_quotations')->onDelete('cascade');
            $table->integer('s_price_id')->unsigned();
            $table->foreign('s_price_id')->references('id')->on('s_prices')->onDelete('cascade');
            $table->string('service_name')->nullable();
            $table->string('service_price')->nullable();



            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('s_quotation_services');
    }
}
