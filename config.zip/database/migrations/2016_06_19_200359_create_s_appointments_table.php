<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSAppointmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('s_appointments', function (Blueprint $table) {

            $table->increments('id');

            $table->integer('customer_id')->unsigned();
            $table->foreign('customer_id')->references('id')->on('users')->onDelete('cascade');

            $table->integer('car_id')->unsigned();
            $table->foreign('car_id')->references('id')->on('customer_cars')->onDelete('cascade');

            $table->integer('mechanic_id')->unsigned();
            $table->foreign('mechanic_id')->references('id')->on('users')->onDelete('cascade');

            $table->enum('status', ['new','under-schedule','scheduled','cancelled','failed','completed'])->default('new');

            $table->enum('payment_type', ['cash-on-hand','credit-card'])->default('cash-on-hand');

            $table->string('price')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('s_appointments');
    }
}
