<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSAppointmentServicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('s_appointment_services', function (Blueprint $table) {
            $table->increments('id');

            $table->integer('s_appointment_id')->unsigned();
            $table->foreign('s_appointment_id')->references('id')->on('s_appointments')->onDelete('cascade');

            $table->integer('s_price_id')->unsigned();
            $table->foreign('s_price_id')->references('id')->on('s_prices')->onDelete('cascade');
            $table->string('s_name')->nullable();
            $table->string('os_name')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('s_appointment_services');
    }
}
