<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateHStatuesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('h_statues', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('h_sub_category_id')->unsigned();
            $table->foreign('h_sub_category_id')->references('id')->on('h_sub_categories')->onDelete('cascade');
            $table->string('name');
            $table->string('desc')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('h_statues');
    }
}
