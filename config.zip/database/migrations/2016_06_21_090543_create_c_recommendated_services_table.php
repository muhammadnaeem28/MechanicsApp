<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCRecommendatedServicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('c_recommended_services', function (Blueprint $table) {

                $table->increments('id');

                $table->integer('c_recommendation_id')->unsigned();
                $table->foreign('c_recommendation_id')->references('id')->on('c_recommendations')->onDelete('cascade');

                $table->integer('s_id')->unsigned();
                $table->foreign('s_id')->references('id')->on('s_category_services')->onDelete('cascade');

                $table->integer('os_id')->unsigned();
                $table->foreign('os_id')->references('id')->on('service_optionals')->onDelete('cascade')->nullable();

                $table->string('desc')->nullable();

                $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('c_recommended_services');
    }
}
